import React, { useState } from "react";
import { View, Text, Image, StyleSheet, ActivityIndicator } from "react-native";
import { ColorsConstant } from "../constants/Colors.constant";
import { StyleConstants } from "../constants/Style.constant";
import FastImage from 'react-native-fast-image';
function Loading(props) {
    return (
        <View style={ls.activityIndicator}>
            <View>
                    <FastImage
                        style={{ width: 100, height: 100 }}
                        source={require('../asstes/Image/loadingI.gif')}
                        resizeMode={FastImage.resizeMode.contain}
                    />
            </View>

        </View>
    )
}
const s = StyleConstants, ls = StyleSheet.create({

    activityIndicator: {
        backgroundColor: ColorsConstant.DarkLight,
        alignItems: 'center',
        justifyContent: "center",
        position: 'absolute',
        zIndex: 9999,
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
    },
})
export default Loading;