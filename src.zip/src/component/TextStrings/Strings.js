export const Strings = {
    login: {
        WelCome: 'Welcome',
        Forgat: `Forgat Password ?`,
        account: "Login to your accont with email and password.",
        SigupDot: `Don't have a acconut ? `,
        Google: "Sign in with Google",
        Twitter: "Sign in with Twitter"
    },
    Register: {
        account: "Create a new accont with  email and password.",
        SigupDot: `Already Have a acconut ? `
    },
    Home: {
        Services: "Buy New Services",
        Privilege: "Privilege Card",
        Subsciption: "Ott Subsciption",
        Tickets: "Tickets",

        Country: "Country Team Council",
        Nominate: "Nominate others",
        File: "File Your Nomination",
        Players: "Players & Masters",
        Form: "Form The Mat ",
        off: "off The Mat",

    }

}
