const IMAGE = {
  eyeon: require('../asstes/Image/eyeon.png'),
  eyeoff: require('../asstes/Image/eyeoff.png'),
  logoVKC: require('../asstes/Image/logo.png'),
  Earn : require('../asstes/Image/earn.png'),
  call: require('../asstes/Image/call.png'),
  promte : require('../asstes/Image/promte.png'),
  plays : require('../asstes/Image/plays.png'),
  watch : require('../asstes/Image/watch.png'),
  learn : require('../asstes/Image/learn.png'),
  Service : require('../asstes/Image/service.png'),
  service2 : require('../asstes/Image/service2.png'),
  service3 : require('../asstes/Image/service3.png'),
  Border : require('../asstes/Image/border.png'), 
  Council : require('../asstes/Image/council.png'),
  Council2 : require('../asstes/Image/council2.png'),
  Mat : require('../asstes/Image/mat-icon.png'),
  Left:require('../asstes/Image/left.png'),
  dropdown : require('../asstes/Image/dropdown.png'),
  userpr:require('../asstes/Image/userpr.png'),
  Rightawwer:require('../asstes/Image/Right.png'),
  logout:require('../asstes/Image/logout.png')

};

export default IMAGE;
