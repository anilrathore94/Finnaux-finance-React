export const fontFamily = {
  bold: "Poppins-Bold",
  extraBold: "Poppins-ExtraBold",
  light: "Poppins-Light",
  medium: "Poppins-Medium",
  Regular: "Poppins-Regular",
  semiBold: "Poppins-SemiBold",

};