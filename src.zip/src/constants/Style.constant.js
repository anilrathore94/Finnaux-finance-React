import { StyleSheet, } from 'react-native'
import { ColorsConstant } from './Colors.constant'
import { fontFamily } from './font'
import { screenHeight, screenWidth } from './Sizes.constant'
export const c = ColorsConstant, StyleConstants = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: ColorsConstant.Thame,
        paddingHorizontal: 16
    },
    Textinput: {
        width: screenWidth - 60,
        // flex:1,
        height: 40,
        marginBottom:10,
        borderRadius: 15,
        paddingHorizontal: 10,
        borderColor: ColorsConstant.bluedark,
        // borderBottomWidth:0.5
        borderWidth:1
    },
    btnoutline: {
        borderWidth: 1,
        width:screenWidth-32,
        // flex: 1,
        height: 50,
        borderRadius: 15,
        paddingHorizontal: 15,
        borderColor: ColorsConstant.White,
        // marginTop: 16
        marginBottom:16
    },
    RowView: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    icon: {
        height: 20,
        width: 20,
    },
    textsigup: {
        color: ColorsConstant.White,
        paddingHorizontal: 15,
        fontSize: 16,
        fontFamily: fontFamily.medium,
    },
    bottunth: {
        backgroundColor: ColorsConstant.bluedark,
        borderRadius: 15,
        height: 46,
        justifyContent: 'center',
        width: screenWidth /2
        // flex:1
    },
    errText: {
        color: ColorsConstant.Error,
        fontSize: 12,
        fontFamily: fontFamily.Regular,
        marginTop:-10,
        marginLeft:50,
        width:screenWidth-32
    },
    ImageI: {
        width: 15,
        height: 15
    },
    cardViewkyc: {
        marginTop: 25,
        backgroundColor: c.cardligth,
        paddingVertical: 20,
        paddingHorizontal: 5,
        borderRadius: 10,
        elevation: 5
    },
    TextBold: {
        color: ColorsConstant.Black,
        fontSize: 18,
        fontFamily: fontFamily.semiBold,
    },
    modalManView: {
        flex: 1,
        alignItems: 'center',
        justifyContent: "flex-end"
    },
    modalLhare: {
        backgroundColor: c.DarkLight,
        opacity: 0.7,
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0
    },
    modalView: {
        backgroundColor: c.White,
        borderRadius: 1,
        padding: 10,
        width: screenWidth,
        // borderRadius:10
    },
    textStylemodal: {
        color: c.Black,
        padding: 10,
        fontFamily:fontFamily.medium
    },
    textitem:{
        color: c.bluedark,
        fontSize:12,
        fontFamily:fontFamily.medium
    }

})