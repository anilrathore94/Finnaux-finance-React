import AsyncStorage from "@react-native-async-storage/async-storage"


const mainUrl = 'https://excellentcoachings.com/'

const base ={
    api: mainUrl +'app-api//',
    token:  AsyncStorage.getItem('token'),
}

export {
    mainUrl,
    base ,
    
}  
