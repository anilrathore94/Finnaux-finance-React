// import AsyncStorage from "@react-native-async-storage/async-storage"
import React, { useEffect } from "react";
import { View, Text, StyleSheet, Image, ImageBackground } from "react-native";
import { ColorsConstant } from "../../constants/Colors.constant";
import { screenHeight, screenWidth } from "../../constants/Sizes.constant";

function Splash(props) {
 useEffect(() => {
    setTimeout( async () => { 
            props.navigation.navigate('Login', { backScreen: 'Splash',} ) 
    }, 1500);
  }, []);
    


    return (
        <> 
            <View style={ls.flexView} >
                <Image source={require('../../asstes/Image/logo.png')} />
            </View>
        </>
    )
}
const ls = StyleSheet.create({
    flexView: {
        flex: 1
        , backgroundColor: ColorsConstant.White,
        alignItems: 'center',
        justifyContent: 'center'
    }

})
export default Splash;