import React, { useEffect, useRef, useState } from "react";
import { View, Text, KeyboardAvoidingView, StyleSheet, ScrollView, Image, TouchableOpacity } from "react-native";
// import LargefillBtn from "../../component/Button/LargefillBtn";
// import LargeOutLineBtn from "../../component/Button/LargeOutLineBtn";
// import PasswordTextInput from "../../component/TextInput/PasswordTextInput";
// import LargeTextInput from '../../component/TextInput/LargeTextInput'
// // import { Strings } from "../../component/TextStrings/Strings";
// import { ColorsConstant } from "../../constants/Colors.constant";
// import { fontFamily } from "../../constants/font"; 
// import { c, StyleConstants } from "../../constants/Style.constant"; 
// import { screenHeight, screenWidth } from "../../constants/Sizes.constant";
// import Toast from 'react-native-toast-message';
// import { loginUser } from "../../services/User";
// // import AsyncStorage from "@react-native-async-storage/async-storage";
// import Loading from "../../component/loading";

function Login(props) {
     
    return (
        <Text>dasdsda</Text> 
    )
}
const  styles = StyleSheet.create({
    // takestep: {
    //     color: ColorsConstant.bluedark,
    //     textAlign: 'center',
    //     fontFamily: fontFamily.medium,
    //     fontSize: 18,
    // },
    // textTop: {
    //     fontSize: 12,
    //     textAlign: 'center',
    //     color: ColorsConstant.bluedark,
    //     fontFamily: fontFamily.semiBold
    // },
    // forgattext: {
    //     color: ColorsConstant.bluedark,
    //     marginBottom: 12,
    //     fontFamily: fontFamily.medium,
    //     fontSize: 12,
    //     width: screenWidth - 80,
    //     textAlign: 'right'
    // },
    // Ortext: {
    //     color: ColorsConstant.bluedark,
    //     // marginTop: 15,
    //     textAlign: 'center',
    //     fontFamily: fontFamily.Regular,
    //     fontSize: 26,
    // }
})
export default Login;


